# Absolutelyautomation.com, 02/2016
# based on Andreas Boesch, 04/2013 code
# Display numeric values (sent as strings) from an external device
# The applications sent a buyte to the device and display the response as text also as a bar
 
# import packages
import Tkinter as tk    	# for the GUI
import ttk              			# for nicer GUI widgets
import tkMessageBox     	# for GUI testbox
import serial           		# for communication with serial port
import time             		# for time stuff
import threading        		# for parallel computing
 
 # A thread that continously request the status of the MWG
class myThread (threading.Thread):
    # initialize class
    def __init__(self, name, ser):
        threading.Thread.__init__(self)
        # Name of thread
        self.name = name
        # Serial port information
        self.ser  = ser
	# the received string
	self.rcvstr=''
	# printable string
	self.prnstr=''
 
    # gets called when thread is started with .start()
    def run(self):
        # counter of the while loop
        self.update_count = 0
        while self.ser.isOpen():

		# increase counter ...
		self.update_count += 1
		# ... and set variable for label shown on the GUI
		readCount.set("Read counts: "+str(self.update_count))

		# for all request commands, send command
            
		try:
			# send command
			self.ser.write("a")
			# wait for Device to answer
			time.sleep(0.1)
			# create string for the answer			
			rcvstr = ''
			# as long as an answer byte is waiting, read the byte
			while self.ser.inWaiting() > 0:				
				self.rcvstr= self.ser.read(self.ser.inWaiting())
		except:
				# do nothing if command could not be send
			pass
 
		# set the label variables with the answers received

		self.prnstr=self.rcvstr.rstrip('\n')
		self.prnstr = self.prnstr +"  C"

		#print self.prnstr
		labelVar.set(self.prnstr)
				
		
		try:
			valueVar.set(float(self.rcvstr)+ offsetBar )
 		except:
			# Do nothing in case the convertion fails due to a strange formatted string
			pass

		# Device interval polling time
		time.sleep(0.5)
             
             
 
# an exit procedure
def mQuit():
    # ask yes/no question to confirm exit
    mExit = tkMessageBox.askyesno(title = "Quit", message = "Do you really want to quit?")
    if mExit > 0:
        # close port
        ser.close()
        # detsroy GUI
        root.destroy()
        return
 
# sending commands to the serial device
def mSend(command):
    try:
        ser.write(command)
    except:
        print "Could not send command. Port closed?"
      
    return
 

         
# ===========================
# Begin of the main program
# ===========================
 
# provide information for serial port
ser = serial.Serial()

# modify according to needs 
ser.port = '/dev/ttyUSB0'
#ser.port = 'COM6'

ser.baudrate = 9600
ser.timeout = 0
# open port if not already open
if ser.isOpen() == False:
    ser.open()
 
# set up root window
root = tk.Tk()
root.configure(background='black')
root.geometry("400x400")
root.title("Serial device variable reading ")
 
# variables 
labelVar 		= tk.StringVar()
readCount		= tk.StringVar()
valueVar		= tk.DoubleVar()

# modify according to needs 
maxBar		= 150.0
minBar		= -50.0

rangeBar		= tk.DoubleVar()
offsetBar		= tk.DoubleVar()

# Text, titles

headerTitle    		= ttk.Label(root, text = "SERIAL DEVICE VARIABLE READING", foreground="white",background="black").grid(row=0, column=1)
headerPort    		= ttk.Label(root, text = "Serial port open: "+str(ser.isOpen()), foreground="white",background="black").grid(row=1, column=1)
headerVarname 	= ttk.Label(root, text = "TEMPERATURE", foreground="white",background="black").grid(row=3, column=1)
headerCounts		= ttk.Label(root,textvariable = readCount, foreground="white",background="black").grid(row=2,column=1)
headerVarvalue	= ttk.Label(root, textvariable = labelVar, foreground="yellow", background="black" ).grid(row=5, column=2)
headerFooter		= ttk.Label(root, text = "Absolutelyautomation.com", foreground="grey",background="black").grid(row=7, column=1)

# Quit button

buttonQuit		= ttk.Button(root, text = "close port and quit", command = mQuit).grid(row=6, column=1)

#Progressbar

if maxBar > 0.0 and minBar >= 0.0 :
	rangeBar = maxBar - minBar
	offsetBar = (-1) * minBar 

if maxBar > 0.0 and minBar < 0.0 :
	rangeBar = maxBar  +abs(minBar)
	offsetBar = abs(minBar) 

if maxBar < 0.0 and minBar < 0.0 :
	rangeBar = abs(minBar) - abs(maxBar)
	offsetBar = abs(minBar) 

s = ttk.Style()
s.theme_use('clam')
s.configure("yellow.Vertical.TProgressbar", foreground='yellow', background='yellow')
progBar = 	ttk.Progressbar(root, orient="vertical",length=200, mode="determinate",maximum=rangeBar,variable=valueVar,style="yellow.Vertical.TProgressbar" ).grid(row=5,column=1)


# wait
time.sleep(1)
# call and start update-thread
thread1 = myThread("Updating", ser)
thread1.start()
 
# start GUI
root.mainloop()